# homepilot-agent – Privilegien-Trennung

**Status:** **Flip vollzogen.** Der Core läuft als `User=homepilot`
(unprivilegiert). Alle root-Operationen laufen über den Agent (97
Operationen); Docker/VMs/Logs über Gruppen; snapraid/Mover dateibasiert
im Core. Verifikation: RC11-Hardwaretest.
**Bauplan:** Kap. 21 (Sicherheitskonzept), Kap. 36 Regel 1.

## Warum

Heute läuft `homepilot-core` als **root**. Das war ein bewusstes Interim
für v0.1 (siehe `docs/iso-build.md`, „Bekannte Grenzen"), aber es
widerspricht dem Bauplan: „Web-GUI läuft nicht als root, privilegierte
Aktionen laufen nur über Agent."

Konkret betrifft das **32 Binaries in 16 Modulen** – von `zpool` und
`mkfs.xfs` über `nft` und `virsh` bis `systemctl`. Jede davon läuft
derzeit im selben Prozess, der auch HTTP-Requests aus dem Browser
verarbeitet.

Der Agent ist außerdem die **Voraussetzung für das gewünschte Terminal**:
Ohne ihn wäre ein Web-Terminal faktisch eine Root-Shell im Browser
(Entscheidung vom 2026-07-20, siehe CLAUDE.md).

## Architektur

```text
Browser ──HTTPS──> nginx ──> homepilot-core          homepilot-agent
                             (User: homepilot)  ──>  (root)
                             unprivilegiert          Policy + Audit
                                          Unix-Socket
                                    /run/homepilot/agent.sock
```

- **Core** läuft als `homepilot` mit systemd-Sandbox. Er kann selbst
  keine privilegierten Kommandos mehr ausführen.
- **Agent** läuft als root, ohne Netzwerk-Listener. Er nimmt
  ausschließlich über einen Unix-Socket Aufträge entgegen.
- **Socket** liegt auf `0660 root:homepilot`. Zusätzlich prüft der Agent
  bei jeder Verbindung die **Peer-Credentials** (`SO_PEERCRED`): nur die
  konfigurierte UID darf Aufträge erteilen. Dateirechte allein genügen
  nicht – ein falsch gesetztes umask oder eine spätere Gruppenänderung
  wäre sonst ein stiller Rechteausbruch.

## Policy-Modell: benannte Operationen, keine Kommandos

Der Core sendet **niemals** einen Binärnamen oder freie Argumente. Er
sendet den Namen einer Operation und benannte Parameter:

```json
{"op": "zfs.pool.list", "params": {}}
{"op": "zfs.dataset.create", "params": {"name": "tank/fotos"}}
```

Der Agent schlägt die Operation in einer **einkompilierten Registry**
nach. Jeder Eintrag legt fest:

- welches Binary ausgeführt wird (absoluter Pfad),
- wie die Argumentliste aus den Parametern entsteht,
- welche Parameter erlaubt und wie sie validiert sind.

Damit gibt es keinen Pfad, über den ein kompromittierter Core – oder ein
Fehler in der API – etwas anderes ausführen kann als die vorgesehenen
Operationen. Eine Policy-Datei zum Nachladen gibt es bewusst **nicht**:
sie wäre ein Angriffsziel und ließe sich zur Laufzeit verbiegen.

### Was das ausschließt

- Kein `sh -c`, kein `bash`, keine Shell. Der Agent startet Prozesse
  direkt (`exec.Command`), Metazeichen haben keine Bedeutung.
- Keine Operation nimmt einen Binärnamen entgegen.
- Kein Parameter wird ungeprüft zu einem Argument; Werte, die wie eine
  Option aussehen (`-x`, `--force`), werden abgewiesen.

## Audit

Jede Ausführung landet im Audit-Log des Agents: Zeitpunkt, aufrufende
UID, Operationsname, Parameter, Exit-Code und Dauer. Fehlgeschlagene
Policy-Prüfungen werden mit dem abgelehnten Namen protokolliert – das ist
das Signal, an dem ein Angriffsversuch sichtbar wird.

## Migration

Der Umbau läuft modulweise, damit das System durchgehend lauffähig
bleibt:

1. **Grundgerüst** (Agent, Protokoll, Policy, Client) – erledigt.
2. **Modul für Modul** – Storage erledigt, Rest offen. Reihenfolge nach
   Risiko: ~~Storage (`zpool`/`zfs`)~~ → Netzwerk (`nft`, `ip`, `wg`) →
   VMs (`virsh`) → Shares → Rest.

   Ein migriertes Modul kennt **keine Binärnamen und keine
   Argumentlisten** mehr. Es sendet Operationen an einen `agent.Runner`.
   Davon gibt es zwei Implementierungen:

   - `*agent.Client` – über den Socket zum Agent (Zielzustand)
   - `*agent.LocalRunner` – im eigenen Prozess (Übergang)

   Beide durchlaufen **dieselbe Policy**: gleiche Registry, gleiche
   Validierung, gleiche Argumentliste, gleiche feste Umgebung. Es gibt
   genau eine Funktion (`runOperation`), an der ein Prozess entsteht.
   Dem lokalen Weg fehlt ausschließlich die Privilegien-Trennung – er
   entfällt ersatzlos, sobald Schritt 3 abgeschlossen ist.

   Der Core wählt beim Start automatisch: Agent erreichbar → Agent,
   sonst lokal mit einer Warnung im Log.
3. **Umschalten**: Core-Unit auf `User=homepilot` mit
   `ProtectSystem=strict`, Agent-Unit als root. Erst wenn alle Module
   migriert sind.
4. **Terminal** (Bauplan-Regel 1 bleibt gewahrt): erst danach, als
   Operation mit eigener Policy und vollständigem Audit – keine freie
   Root-Shell.

Bis Schritt 3 abgeschlossen ist, läuft der Core weiter als root; der
Agent ist dann bereits aktiv, aber noch nicht die einzige Quelle
privilegierter Aktionen.

## Wie der Flip gelöst wurde

Die beiden anfänglichen Blocker sind aufgelöst:

1. **Daten-Zugriff.** Neu angelegte Pools/Datasets/Shares/Mounts bekommen
   über Agent-Operationen die Gruppe `homepilot` + setgid (2775/2770), so
   dass neue Dateien die Gruppe erben. Über SMB angelegte Dateien erhalten
   per `force group = homepilot` + Masken dieselbe Gruppe. Bestandsdaten
   migriert `homepilot-firstboot` einmalig (`chgrp -R` + setgid auf
   Verzeichnisse). Damit erreicht der non-root-Core alle Nutzdaten unter
   `/mnt` – Files-App, Kopia, Cache-Mover.

2. **Streaming.** Gelöst durch Aufgabenteilung statt Streaming im Agent:
   `snapraid sync/scrub`, der Cache-Mover und `snapraid status` arbeiten
   **dateibasiert auf gemounteten Platten** und laufen als `homepilot` im
   Core – der Live-Fortschritt bleibt dort erhalten. Nur die echten
   Root-Aktionen (mkfs, mount, umount, mergerfs, Config-Schreiben) gehen
   über den Agent.

## Aufgabenteilung im Detail

| Bereich | Weg | Warum |
|---|---|---|
| zpool/zfs, nft, mkfs, mount, apt, hdparm, smartctl, … | **Agent** | echte root-Rechte nötig |
| /etc-Schreibzugriffe (Firewall, Samba, WireGuard, snapraid.conf) | **Agent** (WriteFile, fester Pfad) | root-Schreibzugriff |
| sysfs (CPU-Governor, Lüfter-PWM) | **Agent** (exakte Pfad-Muster, `DirectWrite`) | root-Schreibzugriff |
| Restdaten löschen (verwaiste App-Daten, VM-Disks) | **Agent** (`fs.rm.appdata`, `fs.rm.vmdisk`) | Container schreiben als root – der Core darf dort nicht löschen |
| GPU-Auslastung Intel (`intel_gpu_top`) | **Agent** (`gpu.intel.top`) | Leistungszähler brauchen CAP_PERFMON/root |
| Standby-Zustand lesen/setzen (`hdparm -C/-y`) | **Agent** (`disks.powerstate`, `disks.standby`) | ATA-Kommandos brauchen root |
| GPU-Auslastung NVIDIA/AMD | **Core** (homepilot) | nvidia-smi und sysfs sind unprivilegiert lesbar |

### Dateischreibende Operationen

Der zu schreibende Inhalt kommt **immer über Stdin**; den Zielpfad wählt
die Operation, nie der Aufrufer – entweder fest (`WriteFile`) oder aus
einem validierten Parameter berechnet (`WriteFileFn`, zusätzlich durch
`FileUnder` auf ein Verzeichnis begrenzt). Ob eine Operation Stdin annimmt,
entscheidet ausschließlich `Operation.acceptsStdin()`; Agent-Server und
LocalRunner teilen sich diese eine Definition.

### Messwerkzeuge, die nie enden

`intel_gpu_top` misst fortlaufend und endet von sich aus nicht. Für solche
Werkzeuge gibt es zwei Felder an der Operation:

- `Timeout` begrenzt die Laufzeit (bei der GPU-Messung 4 Sekunden),
- `SampleTool` erklärt den Abbruch zum **normalen Ende**: die bis dahin
  gesammelte Ausgabe ist das Ergebnis.

Ohne das zweite Feld würde der Abbruch als Fehlschlag gelten und die
Messung verworfen. Der Parser auf der Core-Seite muss deshalb mit einer
abgeschnittenen Ausgabe umgehen können – er schneidet die vollständigen
JSON-Objekte heraus und nimmt das letzte.

Die einzige Stellschraube ist die Messperiode, begrenzt auf 100–5000 ms:
kürzer wäre Dauerfeuer, länger liefe die Messung über das Timeout hinaus.

### Löschende Operationen

`fs.rm.appdata` und `fs.rm.vmdisk` sind die einzigen Operationen, die
Nutzdaten entfernen. Sie waren nötig, weil ein Container seine App-Daten
als root anlegt: der non-root-Core kann sie danach weder aufräumen noch
beim Deinstallieren mit Datenlöschung entfernen (RC19: „cleanup_failed:
… permission denied").

Ihre einzige Schranke ist das Muster, und es ist bewusst eng:

- `fs.rm.appdata` verlangt einen Pfad **unterhalb** eines
  `.../appdata/<app>`-Verzeichnisses. Die appdata-Wurzel selbst, ein Pool
  oder eine Freigabe sind damit nicht ausdrückbar.
- `fs.rm.vmdisk` verlangt eine einzelne **Datei** mit Disk-Endung
  (`.qcow2`, `.raw`, …) im VM-Verzeichnis – kein Verzeichnis, und ohne
  `-r`.

Der Core versucht immer zuerst selbst zu löschen und geht nur bei
fehlenden Rechten über den Agent; ein Test hält beide Muster gegen eine
Liste von Pfaden fest, die abgelehnt werden müssen.

Geschrieben wird standardmäßig **atomar** (temporäre Datei + Rename), damit
ein Absturz mitten im Schreiben keine kaputte Konfigurationsdatei
hinterlässt. Für **sysfs** ist das unmöglich – dort lassen sich weder neue
Dateien anlegen noch Dateien umbenennen, auch nicht als root. Solche
Operationen setzen deshalb `DirectWrite: true` und schreiben ohne `O_CREATE`
direkt in das bestehende Attribut. Ein Test erzwingt diese Invariante: jede
Operation, die unterhalb von `/sys` schreibt, muss `DirectWrite` gesetzt
haben.
| Docker (compose) | Gruppe `docker` | Socket-Zugriff genügt |
| VMs (virsh, qemu-img) | Gruppe `libvirt`/`kvm` | Gruppenzugriff genügt |
| Log-Viewer (journalctl) | Gruppe `systemd-journal` | Lesezugriff genügt |
| snapraid sync/scrub, Cache-Mover | **Core** (homepilot) | dateibasiert, Streaming |
| Nutzdaten /mnt (Files-App, Backup) | **Core** (homepilot, Gruppe + setgid) | Datenzugriff |
| eigene Scheduler-Skripte | **Core** (homepilot) | sollen nicht als root laufen |

## Migration

Der Umbau läuft modulweise, damit das System durchgehend lauffähig
bleibt:

1. **Grundgerüst** (Agent, Protokoll, Policy, Client) – erledigt.
2. **Modul für Modul** – Storage erledigt, Rest offen. Reihenfolge nach
   Risiko: ~~Storage (`zpool`/`zfs`)~~ → Netzwerk (`nft`, `ip`, `wg`) →
   VMs (`virsh`) → Shares → Rest.

   Ein migriertes Modul kennt **keine Binärnamen und keine
   Argumentlisten** mehr. Es sendet Operationen an einen `agent.Runner`.
   Davon gibt es zwei Implementierungen:

   - `*agent.Client` – über den Socket zum Agent (Zielzustand)
   - `*agent.LocalRunner` – im eigenen Prozess (Übergang)

   Beide durchlaufen **dieselbe Policy**: gleiche Registry, gleiche
   Validierung, gleiche Argumentliste, gleiche feste Umgebung. Es gibt
   genau eine Funktion (`runOperation`), an der ein Prozess entsteht.
   Dem lokalen Weg fehlt ausschließlich die Privilegien-Trennung – er
   entfällt ersatzlos, sobald Schritt 3 abgeschlossen ist.

   Der Core wählt beim Start automatisch: Agent erreichbar → Agent,
   sonst lokal mit einer Warnung im Log.
3. **Umschalten**: Core-Unit auf `User=homepilot` mit
   `ProtectSystem=strict`, Agent-Unit als root. Erst wenn alle Module
   migriert sind.
4. **Terminal** (Bauplan-Regel 1 bleibt gewahrt): erst danach, als
   Operation mit eigener Policy und vollständigem Audit – keine freie
   Root-Shell.

Bis Schritt 3 abgeschlossen ist, läuft der Core weiter als root; der
Agent ist dann bereits aktiv, aber noch nicht die einzige Quelle
privilegierter Aktionen.

## Blocker beim Flip auf Nicht-root

Der Wechsel `User=homepilot` ist **nicht** allein durch die Kommando-
Migration erledigt. Beim Durcharbeiten kamen zwei Punkte zutage, die
zwingend eine Hardware-Verifizierung brauchen:

1. **Daten-Zugriff.** Der Core liest/schreibt Nutzdaten direkt unter
   `/mnt` – die Files-App (Up-/Download), Kopia (liest Shares/Appdata für
   Backups) und der Cache-Mover (verschiebt Dateien zwischen Platten).
   ZFS-Mountpoints und Share-Verzeichnisse gehören root. Als Nicht-root
   kann der Core sie ohne angepasstes Rechtemodell (Gruppen-/ACL-Zugriff
   für `homepilot`, gesetzt beim Anlegen von Pools/Shares + Migration des
   Bestands) nicht mehr erreichen. Ein falsch gesetztes Modell bricht
   entweder den Datenzugriff oder öffnet ein Loch – das lässt sich nur
   auf echter Hardware seriös prüfen.

2. **Streaming.** snapraid `sync`/`scrub` und der Cache-Mover liefern
   Live-Fortschritt. Das Anfrage/Antwort-Modell des Agents streamt nicht;
   eine Migration würde den Fortschrittsbalken einfrieren. Dafür braucht
   der Agent erst eine Streaming-Variante.

**Konsequenz:** Der Core bleibt in RC10 als root (stabil, wie bei
NAS-Systemen üblich). Der Agent ist voll gebaut und übernimmt die
privilegierten Kommandos, wo er erreichbar ist – aber er ist noch nicht
die *einzige* Quelle. Der eigentliche Flip kommt als eigene Runde, sobald
das Rechtemodell auf Hardware verifiziert ist. Die 6 migrierten Module
sind die Vorarbeit dafür.

**Noch nicht migriert (bewusst):** Flex-Array (Streaming), Docker/VMs
(laufen über Gruppen `docker`/`libvirt`, brauchen keinen Agent), Logs
(Gruppe `systemd-journal`), Scheduler-Skripte (sollen als Nicht-root
laufen).

## Vollständiges Audit der direkten `exec.Command`-Aufrufe (2026-07-23)

Alle verbliebenen direkten `exec.Command`-Stellen wurden durchgesehen, um
zu klären, welche noch eine Agent-Migration brauchen. Ergebnis: **keine
weitere sinnvolle, risikofreie Migration offen.** Kategorien:

- **Read-only, kein Privileg nötig** (laufen als Core-Nutzer korrekt):
  `disks/lsblk` (lsblk), `system` (systemctl is-active, via LookPath
  absolut aufgelöst), `logs` (journalctl/systemctl list-units, Gruppe
  `systemd-journal`), `updates` (dpkg-query, apt-get changelog,
  LookPath-Proben), `vm` (qemu-img info, lsusb, `--version`). Diese über
  den Agent zu leiten brächte nur Round-Trip-Overhead ohne
  Sicherheitsgewinn.
- **Läuft bereits unprivilegiert als Core-Nutzer:** `backup/kopia`
  (Backups laufen bewusst als `homepilot`, Datenzugriff über das
  Gruppen-/ACL-Modell), `apps/sources` (git-Clone in den Core-eigenen
  Cache).
- **Socket- statt Kommando-basiert – nicht agent-migrierbar:** `docker`
  spricht den Docker-Socket über einen eigenen HTTP-Client
  (`docker/client.go`); nur `docker compose` nutzt `exec.Command`. Der
  Agent führt fest definierte Kommandos aus, er proxyt keine Socket-API.
  Docker-Zugriff bleibt daher über die Gruppe `docker`.
- **Privileg über Gruppe (Standard, bewusst):** `vm/virsh` (Gruppe
  `libvirt`). Eine virsh-Migration wäre modell-kompatibel, aber groß
  (viele Subkommandos mit XML-Argumenten), widerspricht der bewussten
  Entscheidung und ist nur auf Hardware verifizierbar.
- **Streaming, bewusst im Core:** `flexarray` snapraid sync/scrub +
  Cache-Mover (das Agent-Modell streamt keinen Fortschritt).

**Sicherheitshinweis Docker-Gruppe:** Mitgliedschaft in der Gruppe
`docker` ist faktisch root-äquivalent (ein Container kann `/` des Hosts
mounten). Das ist bei NAS-Systemen mit Docker-Verwaltung der Standard und
eine bewusst akzeptierte Restriktion. Die saubere künftige Minderung ist
**rootless Docker** (dockerd im User-Namespace) – eine eigene, hardware-
verifizierte Infrastruktur-Runde, kein `exec.Command`-Thema.

**Fazit:** Der in RC10 begonnene Übergang ist inhaltlich abgeschlossen –
was privilegiert und agent-tauglich war, läuft über den Agent; der Rest
ist read-only, unprivilegiert, socket-basiert oder bewusst gruppen-/
streaming-gebunden. Der eigentliche `User=homepilot`-Flip bleibt eine
hardware-verifizierte Runde (Rechtemodell unter `/mnt`), unabhängig von
der Kommando-Migration.

## Systemd-Härtung des Agents: was NICHT gesetzt werden darf (2026-07-29)

Der Agent ist ein Prozess, dessen Zweck es ist, fremde Systemwerkzeuge
auszuführen. Systemd-Härtungsdirektiven wirken per seccomp/Namespace und
werden **an alle Kindprozesse vererbt** – eine Direktive, die dem Agent
selbst nicht wehtut, kann deshalb jedes Werkzeug lahmlegen, das er
startet. Zwei solche Direktiven standen in der Unit und haben je eine
ganze Funktionsgruppe stillgelegt (RC17-Hardwaretest):

| Direktive | Wirkung | Was ausfiel |
|---|---|---|
| `RestrictAddressFamilies=AF_UNIX` | `socket(2)` nur für AF_UNIX – **auch für Kindprozesse** | `ip`, `ss`, `nft`, `networkctl`, `ethtool` (alle AF_NETLINK), `apt`, `wg`, `tailscale`, `cloudflared` (AF_INET). Sichtbar: leere Interface-Liste (keine Netzwerkeinstellungen mehr möglich), leere Portliste, Firewall, Wake-on-LAN, apt-Updates |
| `RestrictSUIDSGID=true` | verbietet das Setzen von SUID/SGID – **ausdrücklich auch das setgid-Bit auf Verzeichnissen** | `fs.chmod.setgid` (2775/2770) scheiterte als root mit „Operation not permitted“; das Rechtemodell (Gruppenvererbung auf Pool-/Array-/Share-Wurzeln) griff nie |

Beide sind jetzt entsprechend gesetzt (`RestrictAddressFamilies` auf die
tatsächlich gebrauchten Familien, `RestrictSUIDSGID=false`) – mit
Begründung direkt in der Unit, damit sie niemand „aufräumt“.

**Regel für neue Härtung:** Vor dem Hinzufügen einer Direktive prüfen, ob
sie Kindprozesse betrifft. Der Agent hat keinen Listener, weil sein *Code*
nur den Unix-Socket öffnet – nicht, weil eine seccomp-Regel es erzwingt.

**Zweite Falle derselben Klasse:** `install -d -m …` im firstboot-Skript
setzt den Modus **auch auf bereits vorhandene Verzeichnisse**. Die
postinst des Pakets hatte `/var/lib/homepilot` korrekt auf 0751 gesetzt
(damit `libvirt-qemu` bis zu den VM-Images durchlaufen kann), firstboot
zog es danach wieder auf 0750 zurück – der VM-Start scheiterte mit
„Cannot access storage file … (as uid:64055)“. Werte, die an zwei Stellen
gesetzt werden, müssen an beiden gleich sein.
